#define CR 0x0D
#include <LPC214X.H>
 int transmit(int);
 int receive();
 void intr_init(void);
 void uart_int(void)__irq;
 char ch;
 void init_serial(void);

int main(void)
{
	VPBDIV=0x02;
	init_serial();
	intr_init();
	while(1)
	{
	}
}
void init_serial(void)
{
	PINSEL0 =((1<<16)|(1<<18));
	U1LCR = 0x83;
	U1DLL= 0xB7;
	U1FDR=0xF1;
	U1LCR= 0x03;
	U1IER=0x01;
}
 void intr_init(void)
 {
		
	 VICIntEnable=0x80;
	 VICVectCntl0=0x20|0x07;
	 VICVectAddr0=(unsigned)uart_int;
	 U1IIR= 0x04;
 }
 
 void uart_int(void)__irq
 {
		static int i=0;
		
		if(i==0)
		{
			i=1;
			ch=receive();
		}
		else
		{
			i=0;
			transmit(ch);
		}
		VICVectAddr=0x00;
 }
 
int transmit(int ch)
{
	if(ch=='\n')
	{
		while(!(U1LSR & 0X20));
		U1THR=CR;
	}
	
	while(!(U1LSR & 0x20));
	return (U1THR = ch);
}

int receive()
{
	while(!(U1LSR & 0x01));
	return U1RBR;
}