#include "lpc17xx.h"
#include "system_LPC17xx.h"

uint32_t flag =0;

int main(void)
{
	SystemInit();
	LPC_PINCON->PINSEL4&=~((1 <<22)|(1<<23));
	LPC_GPIO2->FIODIR1 |= (1<<3);

	LPC_SC->PCONP |= (1<<1);
	LPC_SC->PCLKSEL0 |= (1<<2);

	LPC_TIM0->PR = 0x0;
	LPC_TIM0->MR0 = 0x44aa200;
	LPC_TIM0->MCR |= 1 << 0;
	LPC_TIM0->MCR |= 1 << 1;
	LPC_TIM0->TCR |= 1 << 1;
	LPC_TIM0->TCR &= 0 << 1;

	NVIC_EnableIRQ(TIMER0_IRQn);
	LPC_TIM0->TCR |= 1 << 0;
	LPC_GPIO2->FIOSET1 |= (1<<3);

	while(1){}
	return 0;
}


void TIMER0_IRQHandler(void)
{
    if((LPC_TIM0->IR & 0x01) == 0x01)
    {
			LPC_TIM0->IR |= 1 << 0;/* clear interrupt flag */
			if(flag == 0)
			{
				LPC_GPIO2->FIOSET1 |= (1<<3);
				flag = 1;
			}
			else
			{
				LPC_GPIO2->FIOCLR1 |= (1<<3);
				flag = 0;
			}
    }
}
