#include "lpc17xx.h"
#include "system_LPC17xx.h"
#include <stdio.h>

int flag;
int data;
void delay(unsigned long);
char RX();
void TX(char);
char adc[10];
int main()
{
	SystemInit();
	LPC_PINCON->PINSEL1 |= (1<<20);
	LPC_SC->PCLKSEL0 |= (1 << 24);
	LPC_SC->PCONP |=(1<<12);
	LPC_ADC->ADCR |=(1<<3)|(1<<11)|(1<<16)|(1<<21);

	char ch;
	LPC_SC->PCLKSEL1 |=(0<<18)|(0<<19);
	LPC_PINCON->PINSEL0 |=(1<<1)|(1<<3);
	LPC_SC->PCONP |=(1<<25);	
	LPC_UART3->LCR=0x00000083;
	LPC_UART3->DLL=0x000000A2;
	LPC_UART3->DLM=0x00000000;
	LPC_UART3->FDR |=(1<<4);
	LPC_UART3->LCR=0x00000003;	
	
	LPC_PINCON->PINSEL4 |= (1<<24);
	LPC_SC->EXTMODE |=(0<<2);
	LPC_SC->EXTPOLAR |=(0<<2);
	NVIC_EnableIRQ(EINT2_IRQn);

	while(1)
	{
		while(!(LPC_ADC->ADGDR & (1<<31))){};
			data=LPC_ADC->ADDR3; 
			data =((data>>6)&(0x3ff));
			data=(data*5)/1024;
		sprintf(adc,"%d",data);	
			if(flag==1)
			{
		for(int i=0;i<4;i++)
		{
			TX(adc[i]);
	  }
		TX('\r');
		TX('\n');
		flag=0;
	}
}
}	

void EINT2_IRQHandler(void)
{
	LPC_SC->EXTINT |=(1<<2);
	flag=1;	
}

char RX()
{
	while(!(LPC_UART3->LSR & 0x01)){}
	return LPC_UART3->RBR;
}	

void TX(char ch)
{
	while(!(LPC_UART3->LSR & 0x20)){}
	LPC_UART3->THR=ch;
}	
