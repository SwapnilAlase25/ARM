#include "lpc17xx.h"
#include "system_LPC17xx.h"
int flag;
void delay(unsigned long);
int main()
{
	SystemInit();
	LPC_PINCON->PINSEL0 |= (1<<30)|(1<<31);
	LPC_PINCON->PINSEL1 |= (1<<4)|(1<<5);
	LPC_SC->PCLKSEL1 |= (1 << 16);
	LPC_SC->PCONP |=(1<<8);
	LPC_GPIO0->FIODIR|=(1<<16);
	LPC_GPIO2->FIODIR1|=(1<<1);
	LPC_SPI->SPCR=0xe0;
	LPC_SPI->SPCCR=0x0a;
	LPC_GPIO0->FIODIR|=(1<<16);
	NVIC_EnableIRQ(SPI_IRQn);
	
	while(1){
		LPC_GPIO0->FIOSET|=(1<<16);
		LPC_SPI->SPDR=0xff;	
		LPC_GPIO0->FIOCLR|=(1<<16);
		delay(1000);
		LPC_GPIO0->FIOSET|=(1<<16);
		LPC_SPI->SPDR=0x00;	
		LPC_GPIO0->FIOCLR|=(1<<16);
		delay(1000);
		}
}

void SPI_IRQHandler(void)
{
	static int j;
	LPC_SPI->SPINT=0x01;
	
	if(flag==0)
	{
		LPC_GPIO2->FIOCLR1|=(1<<1);
		flag=1;
	}
	else
	{
		LPC_GPIO2->FIOSET1|=(1<<1);
		flag=0;
	}
		j=LPC_SPI->SPDR;
		j=LPC_SPI->SPSR;
}

void delay(unsigned long time)
{
 	int i, j;
	for(i=0;i<10000;i++)
		for(j=0;j<time;j++);
}
