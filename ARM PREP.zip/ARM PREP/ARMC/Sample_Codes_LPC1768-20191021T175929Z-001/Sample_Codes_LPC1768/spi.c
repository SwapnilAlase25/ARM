#include "lpc17xx.h"
#include "system_LPC17xx.h"

int main(void)
{
	int i, j;
	LPC_PINCON->PINSEL0 |= (1<<31)|(1<<30);
	LPC_PINCON->PINSEL1 |= (1<<5)|(1<<4);
	LPC_GPIO0->FIODIR2 |= (1<<0);

	LPC_SPI->SPCR = 0x00;
	LPC_SPI->SPCR |= (1<<5);
	LPC_SPI->SPCCR	 = 0x10;

	while(1)
	{
		LPC_GPIO0->FIOSET2 |= (1<<0);
		LPC_SPI->SPDR = 0x0f;

		while(!(LPC_SPI->SPSR)&(1<<7));

		for(i=0;i<10000;i++)
			for(j=0;j<50;j++);

		LPC_GPIO0->FIOCLR2 |= (1<<0);

		LPC_GPIO0->FIOSET2 |= (1<<0);
	   	LPC_SPI->SPDR = 0xf0;


		while(!(LPC_SPI->SPSR)&(1<<7));		

		for(i=0;i<10000;i++)
			for(j=0;j<50;j++);

		LPC_GPIO0->FIOCLR2 |= (1<<0);
	}
}
