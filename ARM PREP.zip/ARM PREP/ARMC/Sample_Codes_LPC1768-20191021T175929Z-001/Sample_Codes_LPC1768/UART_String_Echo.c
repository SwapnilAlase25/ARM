#include <LPC17xx.h>
#include "system_LPC17xx.h"

char RX();
void TX(char);
char ch[100];

int main(void)
{
	SystemInit();
	LPC_SC->PCLKSEL1 |=(0<<18)|(0<<19);
	LPC_PINCON->PINSEL0 |=(1<<1)|(1<<3);
	LPC_SC->PCONP |=(1<<25);
	
	LPC_UART3->LCR=0x00000083;
	LPC_UART3->DLL=0x000000A2;
	LPC_UART3->DLM=0x00000000;
	LPC_UART3->FDR |=(1<<4);
	LPC_UART3->LCR=0x00000003;
	while(1)
	{	
		int i=0;
		do
		{
			ch[i]=RX();
			i++;
		}while(ch[i-1]!='\r');
		ch[i]='\n';
		ch[i+1]='\0';
		i=0;
		
		while(ch[i])
		{
			TX(ch[i]);
			i++;
		}	
	}	
	return 0;

}
char RX()
{
	while(!(LPC_UART3->LSR & 0x01));
	return LPC_UART3->RBR;
}
void TX(char ch)
{
	while(!(LPC_UART3->LSR & 0x20));
	LPC_UART3->THR=ch;
}