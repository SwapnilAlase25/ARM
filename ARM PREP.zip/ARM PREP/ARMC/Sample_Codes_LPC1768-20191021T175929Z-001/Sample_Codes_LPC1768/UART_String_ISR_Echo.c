#include <LPC17xx.h>
#include "system_LPC17xx.h"

char ch[100];
int i;
int flag;

int main()
{
	SystemInit();
	LPC_SC->PCLKSEL1 |=(0<<18)|(0<<19);
	LPC_PINCON->PINSEL0 |=(1<<1)|(1<<3);
	LPC_SC->PCONP |=(1<<25);
	
	LPC_UART3->LCR=0x00000083;
	LPC_UART3->DLL=0x000000A2;
	LPC_UART3->DLM=0x00000000;
	LPC_UART3->FDR |=(1<<4);
	LPC_UART3->LCR=0x00000003;
	LPC_UART3->IER=0X00000001;
	NVIC_EnableIRQ(UART3_IRQn);
	
	while(1)
	{	
		if(flag==1)
		{
			i=0;
			while(ch[i])
			{
				LPC_UART3->THR=ch[i];
				i++;
			}
			flag=0;
			i=0;
		}
	}	
	return 0;
}
void UART3_IRQHandler(void)
{
	if(LPC_UART3->IIR & 0x04)
	{
		ch[i]=LPC_UART3->RBR;
		i++;
		if(ch[i-1]=='\r')
		{
		ch[i]='\n';
		ch[i+1]='\0';	
		flag=1;
		}
	}	
}
