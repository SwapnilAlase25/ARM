#include<LPC214x.h>

void timer1_init();
void timer_delay_reset();
void timer_delay_stop();

int main()
{
	timer1_init();
	//while(1)
	//{
		IO0SET=(1<<31);
		timer_delay_reset();
		IO0CLR=(1<<31);
		timer_delay_stop();
	//}
	
}

void timer1_init()
{
	 VPBDIV=0x02;
	 T1PR=0x7529;
	 T1MR0=0x3EB;
	 T1CTCR=0x00;
	 T1TCR=0x02;
	 IO0DIR=(1<<31);	
	 
}

void timer_delay_reset()
{
    T1MCR=(1<<1);
		T1TCR=0x01;
	  while(T1TC<T1MR0);
	  T1TCR=0x02;
}

void timer_delay_stop()
{
    T1MCR=(1<<2);
		T1TCR=0x01;
	  while(T1TC<T1MR0);
	  T1TCR=0x02;
}
