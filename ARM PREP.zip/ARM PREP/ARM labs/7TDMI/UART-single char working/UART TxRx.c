#include <LPC214x.h>
#define F_CPU 60000000
void UART_init()
{
	PINSEL0|=(1<<16)|(1<<18);                //To use PORT0 as TX and RX
	VPBDIV=0x02;                             //set 30Mhz PCLK
	
	U1LCR=(1<<7)|(1<<1)|(1<<0);            //latching and setting the data size as 8bits
	U1DLM=0x00; 
	U1DLL=0xB7;                            //defining baud rate
  U1FDR=(1<<0)|(1<<4)|(1<<5)|(1<<6)|(1<<7);	//setting baud rate
	U1LCR&=(~(1<<7));                     //remove latch 
	
	U1TER=(1<<7);                         //enable transmission
	//U1FCR=(1<<0);
		
}

int main()
{
	UART_init();                          //initialize UART
	
	while(1)
	{
		while(!(U1LSR&(1<<0)));            //check for data reception
		char ch=U1RBR;                     //read U1RBR data

		U1THR=ch;                          //assign data to U1THR for transmission
		while(!(U1LSR&(1<<5)));            //wait for transmission to be over
				
	}
		
}
