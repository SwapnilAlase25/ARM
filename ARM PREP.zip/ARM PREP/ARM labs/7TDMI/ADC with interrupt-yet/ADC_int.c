#include<LPC214x.h>
#include "LCD7TDMI.h"
#include<stdio.h>

void delay1()
{
	for(int j=0;j<=0xFFF;j++)
	for(int k=0;k<=0xFFF;k++);
	
}
/*void displayOnLCD()
{
	long int data;
	float data1;
	char par[10];  //="HELLO";
	data=((AD0DR3>>6)&0x3FF);
	data1=((3.3/1024)*data);
	sprintf(par,"%f",data1);
	send_cmd(0x01);
	delay1();
	send_cmd(0x80);
	delay1();
		send_cmd(0x01);
		delay1();
	for(int i=0;par[i]!='\0';i++)
	{
	    send_data(par[i]);
		 delay1();
	}
}
*/
void ADC_isr(void)__irq
{
	//delay1();
if(AD0STAT&(1<<3))
{
		//IO0SET=(1<<31);
    //displayOnLCD();
	long int data;
	float data1;
	char par[10];  //="HELLO";
	data=((AD0DR3>>6)&0x3FF);
	data1=((3.3/1024)*data);
	sprintf(par,"%f",data1);
	send_cmd(0x01);
	delay1();
	send_cmd(0x80);
	delay1();
		send_cmd(0x01);
		delay1();
	for(int i=0;par[i]!='\0';i++)
	{
	    send_data(par[i]);
		 delay1();
	}
}

VICVectAddr=0x00;
}	

void ADC_init()
{
	
//enable interrupts 
VICIntEnable|=(1<<18);
VICVectCntl1|=(0x20)|18;
VICVectAddr1=(unsigned int)ADC_isr;
//set and unable ADC to work in interrupt mode
PINSEL1|=(1<<28);            //   P0.30 as ADC
VPBDIV=0x00;
AD0CR=0x00;
AD0CR|=(1<<3)|(1<<16)|(1<<21);
AD0CR|=0x0000FF00;
//IODIR0=(1<<31);
}

int main()
{
	init_lcd();
	ADC_init();
	//init_lcd();
	
	while(1)
	{
		
	}
}
