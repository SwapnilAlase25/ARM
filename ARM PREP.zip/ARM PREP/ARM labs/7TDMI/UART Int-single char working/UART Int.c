#include <LPC214x.h>
#define F_CPU 60000000
void UART_init()
{
	PINSEL0|=(1<<16)|(1<<18);                //To use PORT0 pin 8 and 9 as UART1 TX and RX
	VPBDIV=0x02;                             //set 30Mhz PCLK
	
	U1LCR=(1<<7)|(1<<1)|(1<<0);            //latching and setting size as 8 bit
	U1DLM=0x00;
	U1DLL=0xB7;                            //setting DLL for baudrate
  U1FDR=(1<<0)|(1<<4)|(1<<5)|(1<<6)|(1<<7);	//setting baud rate
	U1LCR&=(~(1<<7));                     //remove latch 
	
	U1TER=(1<<7);                         //enable transmit
	//U1FCR=(1<<0);
		
}
void uart1_isr(void)__irq               //defining the ISR for UART1
{
	
 if(U1IIR==0x04)                        //checking the Interrupt type , if the recieve data is ready 
 {
	IO0CLR|=(1<<31);                      //turn off led
	char ch=U1RBR;                        //fetch the value into register
   U1THR=ch;                            //load into U1THR
 }	      
 if(U1IIR==0x02)                        //checking the Interrupt type,if the THRE is empty
 {
	 IO0SET|=(1<<31);                     //turn off light
		char ch=U1RBR;                      //load into character
 }
	VICVectAddr=0x00;                     //reset the VIC address
}
void uart_Int_init()                    //initialize the UART
{
	U1IER=(1<<1)|(1<<0);                  //Enable RX and TX interrupt
	VICIntEnable|=(1<<7);                 //enable the irq slot
	VICVectAddr0=(unsigned long)uart1_isr;//load address
	VICVectCntl0=0x20|7;                  //enable 7th slot
}

int main()
{
	IO0DIR|=(1<<31);                      //set direction as output for Connect
	IO0DIR|=(1<<25);                      //set direction as output for buzzer
	UART_init();                          //call initialization function
	IO0SET|=(1<<31);	                    //turn off light
	uart_Int_init();                      //call initialization of int
 		while(1)
	{
				
	}
		
}

