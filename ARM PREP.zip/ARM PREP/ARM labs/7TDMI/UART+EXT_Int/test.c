#include<LPC214x.h>
int i=0;
char str[30];
void Ext_isr(void)__irq               //defining ISR for Ent Int
{
	static int i=0;                     //to use ISR for different functions
	if(i==0)
	{
		//recieve string
		i=1;                      
		IO1CLR=(1<<25);                   //turn on buzzer
	for(int j=0;j<=29;j++)              //recieve string from UART
	 {
		while(!(U1LSR&(1<<0)));           //waiting for receive from UART
		char ch=U1RBR;                    //copy register
    if(ch=='\r')                      //check for string end
		{
			break;
	  }
    else
		{	
   			str[j]=ch;                    //copy into string
		  j++;			
		}
	str[j]='\0';                        //end of string
	}
}
	else if(i==1)
	{
		//transmit string
		i=2;
		IO1SET=(1<<25);                   //turn off buzzer
		for(int j=0;j<=6;j++)             //transmit string to UART
			{
			U1THR=str[j];
			while(!(U1LSR&(1<<5)));
			}
	}
	else if(i==2)
	{
		i=3;
		IO0CLR=(1<<31);                 //turn on LED
		
	}
	else
	{
		i=0;
		IO0SET=(1<<31);                  //turn off LED
	}
	EXTINT|=(1<<2);                  //clearing interrupt
  VICVectAddr=0x00;	               //resetting the address
} 
void uart_init()
{
  PINSEL0|=(1<<16)|(1<<18);        //Set Port 0 pins to enable TX1 and RX1
	VPBDIV=0x01;                     //set frequency to 60MHz
	U1LCR=(1<<7)|(1<<0)|(1<<1);      //latching and 8 bit size
  U1DLL=0x6E;                      //to calculate baud rate
	U1DLM=0x01;                      //to calculate baud rate
	U1FDR=(1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0); //to set MulVal and DivAddVal
	U1LCR&=(~(1<<7));                //disable latch
	U1TER=(1<<7);                    //enable transmission
}

void Ext_init()
{
	IO1DIR=(1<<25);                 //setting direction for Buzzer port         
	IO0DIR=(1<<31);                 //Setting direction for LED port
	PINSEL0|=(1<<31);                 //selecting EINT2 function of P0.31
	EXTINT=(1<<2);                   //enabling EINT2
	EXTMODE=(1<<2);                  //setting level triggered mode
	EXTPOLAR=(1<<2);                 //setting active high trigger
	VICIntEnable=(1<<16);            //enable EINT2 for VIC
	VICVectAddr0=(unsigned int)Ext_isr; //setting the VIC address 
	VICVectCntl0=0x20|0x10;    //slot 16 enabled
}

int main()
{ 
	uart_init();
	Ext_init();                     //initializing the funtion
	IO1SET=(1<<25);                 //switching off buzzer
	IO0SET=(1<<31);                 //switching off LED
 	while(1)                        //holding the output
	{
		
	}
	
}

