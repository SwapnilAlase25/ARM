#include<lpc214x.h>
#include<string.h>
#define F_CPU 60000000

  char ch;
	char str[30];
	int i=-1;
void uart_init()                        //initializes the UART1
{
	
	PINSEL0=(1<<16)|(1<<18);              //selects the Port0 pin8 and pin 9 as UART1 TX and RX
	VPBDIV=0x02;                          //Determines the PCLK same as CCLK , 60MHz
	U1LCR=(1<<7)|(1<<1)|(1<<0);           //Enables the DLAB(latching), sets the data size as 8 bit
	U1FDR=(1<<0)|(1<<4)|(1<<5)|(1<<6)|(1<<7); //Defines the MULVAL and DIVADDDVAL for baudrate calculation
	U1DLL=0xB7;                           //Defines the DLL value for calculating baud rate
	U1DLM=0x00;                           //Defines the DLM value for calculating baud rate
	U1LCR&=(~(1<<7));                     //clears the DLAB
   U1TER=(1<<7);                        //enables transmission
}




void pola_isr()__irq               //defines the IRQ 
{

	if(U1IIR==0x02)                 //transmit data interrupt
	{
     for(int j=0;j<=strlen(str);j++)   //loop for transmitting data
		{
			  U1THR=str[j];              //load data into transmit register
			  for(int p=0;p<=200000;p++); //delay to allow transmission of all character
			
		}
			U1IER|=(1<<0);               //allow recieve interrupt
		  U1IER&=(~(1<<1));
		  i=-1;
	}
  if(U1IIR==0x04)              //recieve interrupt
	{
			i++;                     //increment the count for input 
      ch=U1RBR;                //copy the data into char ch
      if(i<28)                 //limits the input count
			{
      if(ch=='\r')	           //checks for end of input
			{
          str[i]='\0';         //terminates the input string
				  U1IER&=(~(1<<0));    //disable recieve interrupt
				  U1IER|=(1<<1);       //enable transmit interrupt
				  U1THR=':';           //Transmit the end
			}
      else
      {
        str[i]=ch;             //copy the data into string
			
			}		
		}
 else{
	     str[i]='\0'; 
       U1IER&=(~(1<<0));      //disable the recieve interrupt at strlen end
			 U1THR=':';          //tranmsit a symbol to signify end
     }	
	}
VICVectAddr=0x00;           //load the address of start , de-allocate the stroed ISR address
}

void uart_int()             //Initialize interrupts
{
U1IER=(1<<0)|(1<<1);        //Enable Rx and Tx interrupt
VICIntEnable=(1<<7);        //Enables the UART1 interrupt 
VICVectCntl0=0x20|7;        //enables the slot and assigns the 7th slot value
VICVectAddr0=(unsigned int )pola_isr; //load the efined isr address to vect
}

int main()
{

uart_init();             //call initialize function
uart_int();              //call interrupt 
while(1)
{
}

}