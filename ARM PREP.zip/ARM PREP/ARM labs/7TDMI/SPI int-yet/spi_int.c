#include<LPC214x.h>

void spi_isr()__irq                    
{
  
	S0SPINT=(1<<0);        
if(!(IO0SET&(1<<7))) 
		IO0SET|=(1<<7);	            //why???
	IO0CLR|=(1<<31);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	IO0SET|=(1<<31);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	char j;
	j=S0SPDR;
	j=S0SPSR;
  VICVectAddr=0x00;
	
}


void spi_init()
{
	PINSEL0=(1<<12)|(1<<8);
	IO0DIR|=(1<<7);
  VPBDIV=0x00;
	S0SPCCR=0x08;
	S0SPCR=(1<<5)|(1<<6)|(1<<7)|(1<<11);
	VICIntEnable=(1<<10);
	VICVectCntl0=0x20|10;
	VICVectAddr0=(unsigned int)spi_isr;

}



int main()
{

spi_init();
	
	

while(1)
{
IO0CLR|=(1<<7);
S0SPDR=(0x0A);
	IO0SET|=(1<<7);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	

	IO0CLR|=(1<<7);
S0SPDR=(0xA0);
	IO0SET|=(1<<7);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	
	
}


}