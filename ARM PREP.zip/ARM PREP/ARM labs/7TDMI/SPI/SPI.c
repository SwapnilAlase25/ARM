#include<LPC214x.h>

void SPI_Init()
{
	PINSEL0=(1<<8)|(1<<12);
	VPBDIV=0x00;
	S0SPCR=(1<<5)|(1<<6)|(1<<11);
	S0SPCCR=0x0E;
	IO0DIR=(1<<7);
}
void transmit()
{ 

	IO0CLR=(1<<7);
	S0SPDR=0xF0;
	IO0SET=(1<<7);
	while(!(S0SPSR&(1<<7)));
	char ch=S0SPDR;
	
}
int main()
{
	SPI_Init();
	//transmit();
	while(1)
	{
		transmit();
	}
	
}