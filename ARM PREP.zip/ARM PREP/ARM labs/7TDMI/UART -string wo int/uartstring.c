#include<lpc214x.h>


void uart_init()                           //initialize UART 
{
PINSEL0=(1<<16)|(1<<18);                   //Select PORT0 pins 8 and 9 as Rx and TX
	VPBDIV=0x01;                             //select PCLK same CCLK 
	U1LCR=(1<<7)|(1<<0)|(1<<1);              //latching and setting size as 8-bit
  U1DLL=0x6E;                              //setting the DLL for baud rate determination
	U1DLM=0x01;                              //setting DLM for baud rate determination
	U1FDR=(1<<7)|(1<<6)|(1<<5)|(1<<4)|(1<<0);//setting MULVAL and DIVADDVAL as 15 and 1
	U1LCR&=(~(1<<7));                        //remove latching 
	U1TER=(1<<7);                            //Enable transmission
}

int main()
{

uart_init();                               //initialize of UART
int i=0;
char str[30];
	for( i=0;i<=29;i++)                     //receive string 
	{
		while(!(U1LSR&(1<<0)));               //check for recieve flag to be set
		char ch=U1RBR;
    if(ch=='\r')
		{
			break;
	  }
    else		
			str[i]=ch;
	}
	str[i]='\0';
	
		for(int i=0;str[i]!='\0';i++)         //transmit string
	{
	U1THR=str[i];
		while(!(U1LSR&(1<<5)));               //wait for transmission to be complete
	}
while(1)
{
}


}