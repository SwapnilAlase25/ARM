#include<LPC214x.h>

void Ext_isr(void)__irq               //defining ISR for Ent Int
{
	static int i=0;
	//IO0CLR=(1<<31); 
	if(i==0)
	{
		i=i+1;
		IO1CLR=(1<<25);                   //turn on light
		
	}
	else if(i==1)
	{
		i=i+1;
		IO1SET=(1<<25);                  //turn off light
		
	}
	else if(i==2)
	{
		i=i+1;
		IO0CLR=(1<<31);                 //turn on LED
		
	}
	else
	{
		i=0;
		IO0SET=(1<<31);                  //turn off LED
	}
	EXTINT|=(1<<2);                  //clearing interrupt
  VICVectAddr=0x00;	               //resetting the address
}
void Ext_init()
{
	IO1DIR=(1<<25);                 //setting direction for Buzzer port         
	IO0DIR=(1<<31);                 //Setting direction for LED port
	PINSEL0=(1<<31);                 //selecting EINT2 function of P0.31
	EXTINT=(1<<2);                   //enabling EINT2
	EXTMODE=(1<<2);                  //setting level triggered mode
	EXTPOLAR=(1<<2);                 //setting active high trigger
	VICIntEnable=(1<<16);            //enable EINT2 for VIC
	VICVectAddr0=(unsigned int)Ext_isr; //setting the VIC address 
	VICVectCntl0=0x20|0x10;    //slot 16 enabled
}

int main()
{ 
	
	Ext_init();                     //initializing the funtion
	IO1SET=(1<<25);                 //switching off buzzer
	IO0SET=(1<<31);                 //switching off LED
 	while(1)                        //holding the output
	{
		
	}
	
}
