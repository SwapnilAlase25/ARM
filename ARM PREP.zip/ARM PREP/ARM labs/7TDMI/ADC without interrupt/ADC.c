#include<LPC214x.h>
#include"LCD7TDMI.h"
#include<stdio.h>
#include<string.h>

void adc_init()
{
	
//	IO0DIR=(1<<31);
	PINSEL1=(1<<28);
	VPBDIV=0x00;
  AD0CR=0x00;
  AD0CR|=(1<<3)|(1<<16)|(1<<21);
	AD0CR|=0x0000ff00;
}


int main()
{
	init_lcd();
  adc_init();
  long int data;
	float data1;
	char buf[10];

	while(1){
	
	while(!(AD0DR3&(1<<31)));
	data=((AD0DR3>>6)&(0x03FF));
	data1=data*3.3;
	data1=data1/1024;
	sprintf(buf,"ADC=%f",data1);
	send_cmd(0x80);
	delay(); 
	for(int i=0;buf[i]!='\0';i++)
 {
	send_data(buf[i]);
	  delay(); 
 } 
 	
	}

}

