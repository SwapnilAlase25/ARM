#include <LPC214x.h>
#include "LCD7TDMI.h"	
	
int main(void)
{
	init_lcd();
	send_cmd(0x80);
	for(int i=0;i<4;i++)
	send_data('g');
	send_cmd(0xc0);
	for(int i=0;i<4;i++)
	send_data('k');
	while(1);
}
