/*
  i2c support for LPC21XX
  Includes drivers:
   - EEPROM 24XX series (from 24XX04 to 24XX512)

*/



#include <LPC214x.H>                       /* LPC214x definitions */
#include "i2c.h"



#ifndef NULL
#define NULL 0
#endif


#define SCHL 75
//===========================================================================
//================ Common routines ==========================================
//===========================================================================
void i2c_lpc_init(int Mode)
{
  PINSEL0 = (PINSEL0 & ~(3 << 4)) | (1 << 4);
  PINSEL0 = (PINSEL0 & ~(3 << 6)) | (1 << 6);

   if(Mode == I2C_SPEED_400)
   {
  //--- I2C Timing for 58 MHz (t = 16.954 ns) ---
      I2C0SCLH = SCHL;  //-- more then 0.6 us  - 0.8
      I2C0SCLL = SCHL;  //-- more then 1.3 us  - 1.4
   }
   else //Slow
   {
      I2C0SCLH = SCHL*4;
      I2C0SCLL = SCHL*4;
   }

   I2C0CONCLR = 0xFF;           //-- Clear all flags
   I2C0CONSET = 0x40;           //-- Set Master Mode
   I2C0CONSET |= I2C_FLAG_I2EN; //--- Enable I2C
}

//---------------------------------------------------------------------------
static void i2c_lpc_wr_byte(int byte)
{
   I2C0DAT = byte;
   I2C0CONCLR = I2C_FLAG_SI;                //-- Clear SI
   while(!(I2C0CONSET & I2C_FLAG_SI));      //-- End wr POINT
}

//---------------------------------------------------------------------------
static void i2c_lpc_stop()
{
    //-- Set STOP condition
   I2C0CONCLR = I2C_FLAG_SI;                  //-- Clear SI
   I2C0CONSET |=  I2C_FLAG_AA | I2C_FLAG_STO; //-- Clear NO ASK
}

//---------------------------------------------------------------------------
static int i2c_lpc_ctrl(int ctrl)
{
   int chk;
   //-- Set START
   I2C0CONCLR = 0xFF; // Clear all bits
   I2C0CONSET |= I2C_FLAG_I2EN | I2C_FLAG_STA;
   while(!(I2C0CONSET & I2C_FLAG_SI));      //--- End START
   //-- Set ADDRESS
   I2C0DAT = ctrl;
   I2C0CONCLR = I2C_FLAG_STA | I2C_FLAG_SI; //-- Clear START & SI
   if(ctrl & 1) //-- RD
      chk = 0x40; //-- 40H - SLA+R has been transmitted; ACK has been received
   else
      chk = 0x18; //-- 18H - SLA+W has been transmitted; ACK has been received
   while(!(I2C0CONSET & I2C_FLAG_SI));      //-- End CTRL
   if(I2C0STAT != chk)
   {
      i2c_lpc_stop();
      return I2C_ERR_NO_RESPONSE;
   }
   return I2C_NO_ERR;
}

//---------------------------------------------------------------------------
static int i2c_lpc_rx_to_buf(char * buf,int num)
{
   int rc;

   if(buf == NULL)
      return I2C_ERR_WRONG_PARAM;

   rc = num;
   if(rc > 1)
   {
      I2C0CONCLR = I2C_FLAG_SI;
      I2C0CONSET |= I2C_FLAG_AA;
      for(;;)
      {
         while(!(I2C0CONSET & I2C_FLAG_SI));  //-- End Data from slave;
         *buf++ = (unsigned char)I2C0DAT;
         rc--;
         if(rc <= 0)
            break;
         else if(rc == 1)
            I2C0CONCLR = I2C_FLAG_AA | I2C_FLAG_SI;  //-- After next will NO ASK
         else
         {
            I2C0CONCLR = I2C_FLAG_SI;
            I2C0CONSET |= I2C_FLAG_AA;
         }
      }
   }
   else if(rc == 1)
   {
      I2C0CONCLR = I2C_FLAG_AA | I2C_FLAG_SI;  //-- After next will NO ASK
      while(!(I2C0CONSET & I2C_FLAG_SI));  //-- End Data from slave;
      *buf = (unsigned char)I2C0DAT;
   }
   else //err
      return I2C_ERR_WRONG_PARAM;

   return I2C_NO_ERR;
}
//----------------------------------------------------------------------
static int i2c_lpc_ask_polling_op(int ctrl)  //-- wait until write finished
{
   int rc;
   int i;

   for(i=0;i < I2C_WR_24XX_TIMEOUT; i++) //-- actually wr = ~110 but timeout =10000

   {
      I2C0CONSET = I2C_FLAG_STA;
      I2C0CONCLR = I2C_FLAG_SI;  //-- Here - clear only SI (not all I2C0CONCLR)
      while(!(I2C0CONSET & I2C_FLAG_SI));        //wait the ACK

      I2C0DAT = ctrl & 0xFE;; // R/WI = 0
      I2C0CONCLR = I2C_FLAG_SI | I2C_FLAG_STA; //-- Clear START & SI
      while(!(I2C0CONSET & I2C_FLAG_SI));//wait the ACK
      rc = I2C0STAT;
      if(rc == 0x18) //-- got ACK after CLA + W
         break;
     
   }
   if(i == I2C_WR_24XX_TIMEOUT)
      return I2C_ERR_24XX_WR_TIMEOUT;
   return I2C_NO_ERR;
}
//===========================================================================
//================ EEPROM 24XX series ========================================
//===========================================================================

//----------------------------------------------------------------------------
static int m24xx_page_size(int eeprom_type, int eeprom_addr,int * pg_sz)
{
   int page_size,rc;

   page_size = 0;
   rc = I2C_NO_ERR;
   switch(eeprom_type)
   {
           case EEPROM_24XX256:
         if(eeprom_addr > EEPROM_MAX_ADDR_24XX256)
            rc = I2C_ERR_24XX_BAD_ADDR;
         else
            page_size = 64;
         break;
      case EEPROM_24XX512:
         if(eeprom_addr > EEPROM_MAX_ADDR_24XX512)
            rc = I2C_ERR_24XX_BAD_ADDR;
         else
            page_size = 128;
         break;
   }
   if(rc != I2C_NO_ERR)
      return rc;
   if(page_size == 0)  //-- Bad eeprom_type
      return I2C_ERR_24XX_BAD_TYPE;

   if(pg_sz)
      *pg_sz = page_size;
   return I2C_NO_ERR;
}
//----------------------------------------------------------------------------
static int m24xx_set_addr(
    int eeprom_type,     //-- EEPROM type
    int eeprom_addr,     //-- start eeprom addr ( not included Hardware A2,A1,A0)
    int eeprom_cs_val,   //-- Hardware A2,A1,A0 (valid from 24XX32)
    int * ctrl_val,      //-- Value of ctrl(return)
    int * addr_hi_val,   //-- Value of addr_hi(return)
    int * addr_lo_val)   //-- Value of addr_lo(return)
{
   int ctrl;
   int addr_hi;
   int addr_lo;
   int rc;

   rc = I2C_NO_ERR;
   ctrl = 0;
   addr_hi = 0;
   addr_lo = 0;

   switch(eeprom_type)
   {
      
      case EEPROM_24XX256:

         ctrl = (eeprom_cs_val<<1) & 0x07; //-- 00001110
         ctrl |= 0xA0; //-- 1010xxxx
         addr_hi = (eeprom_addr>>8) & 0x7F;
         addr_lo = eeprom_addr & 0xFF;
         break;

      case EEPROM_24XX512:

         ctrl = (eeprom_cs_val<<1) & 0x07; //-- 00001110
         ctrl |= 0xA0; //-- 1010xxxx
         addr_hi = (eeprom_addr>>8) & 0xFF;
         addr_lo = eeprom_addr & 0xFF;
         break;
   }
   if(rc != I2C_NO_ERR)
      return rc;
   if(ctrl == 0)
      return I2C_ERR_24XX_BAD_TYPE;

   if(ctrl_val)
      *ctrl_val = ctrl;
   if(addr_hi_val)
      *addr_hi_val = addr_hi;
   if(addr_lo_val)
      *addr_lo_val = addr_lo;

   return I2C_NO_ERR;
}

//----------------------------------------------------------------------------
static int i2c_lpc_m24xx_wr(
     int eeprom_type,    //-- EEPROM type
     int eeprom_addr,    //-- start eeprom addr ( not included Hardware A2,A1,A0)
     int eeprom_cs_val,  //-- Hardware A2,A1,A0 (valid from 24XX32)
     char * buf,         //-- Data srs buf
     int num )            //-- Bytes to write qty
{
   int rc;
   int ctrl;
   int addr_hi;
   int addr_lo;

   rc = m24xx_set_addr(eeprom_type,eeprom_addr,eeprom_cs_val,
                                  &ctrl,&addr_hi,&addr_lo);
   if(rc != I2C_NO_ERR)
      return rc;

   //--- wr START + CONTROL
   rc = i2c_lpc_ctrl(ctrl); //-- Now WR (RD/WI = 0)
   if(rc != I2C_NO_ERR)
      return rc;
   //--- wr ADDRESS
   i2c_lpc_wr_byte(addr_hi);
   if(addr_lo != -1)
      i2c_lpc_wr_byte(addr_lo);
   //---  Write  data
   while(num--)                 //-- transmit data until length>0
   {
      rc = *buf++; //---
      i2c_lpc_wr_byte(rc);
   }
   //-----------------------
   i2c_lpc_stop();

   rc = i2c_lpc_ask_polling_op(ctrl);    //-- wait until write finished
   i2c_lpc_stop();
   return I2C_NO_ERR;
}

//----------------------------------------------------------------------------
int m24xx_write(
    int eeprom_type,    //-- EEPROM type
    int eeprom_addr,    //-- start eeprom addr ( not included Hardware A2,A1,A0)
    int eeprom_cs_val,  //-- Hardware A2,A1,A0 (valid from 24XX32)
    char * buf,         //-- Data src buf
    int num)            //-- Bytes to write qty
{
   int page_size = 0;
   int rc;
   int b_to_wr;


   rc = I2C_NO_ERR;
   for(;;)
   {
      rc = m24xx_page_size(eeprom_type,eeprom_addr,&page_size);
      if(rc != I2C_NO_ERR)
         break;
      if(page_size == 0)
      {
         rc = I2C_ERR_24XX_BAD_PAGESIZE;
         break;
      }

      rc = eeprom_addr%page_size;
      if(rc != 0) //-- not fit on page alignment
      {
         b_to_wr = page_size - rc;
         if(num < b_to_wr)
            b_to_wr = num;
         if(b_to_wr > 0)
         {
             rc = i2c_lpc_m24xx_wr(eeprom_type,eeprom_addr,eeprom_cs_val, buf,b_to_wr);
             if(rc != I2C_NO_ERR)
                break;
             num -= b_to_wr;
             eeprom_addr += b_to_wr;
             buf += b_to_wr;
         }
      }
       //--- write remainder(by pages,if possible)
      while(num > 0)
      {
          if(num < page_size)
             b_to_wr = num;
          else
             b_to_wr = page_size;

          rc = i2c_lpc_m24xx_wr(eeprom_type,eeprom_addr,eeprom_cs_val, buf,b_to_wr);
          if(rc != I2C_NO_ERR)
             break;
          num -= b_to_wr;
          eeprom_addr += b_to_wr;
          buf += b_to_wr;
      }

      break;
   }


   return rc;
}

//----------------------------------------------------------------------------
int m24xx_read(
  int eeprom_type,    //-- EEPROM type
  int eeprom_addr,    //-- start eeprom addr ( not included Hardware A2,A1,A0)
  int eeprom_cs_val,  //-- Hardware A2,A1,A0 (valid from 24XX32)
  char * buf,         //-- Data dst buf
  int num)            //-- Bytes to read qty
{
   int page_size;
   int rc;
   int ctrl;
   int addr_hi;
   int addr_lo;



   rc = I2C_NO_ERR;
   for(;;)
   {
      if(num <=0)
      {
         rc = I2C_ERR_24XX_WRONG_NUM;
         break;
      }
       //--- Here - just for addr checking
      page_size = 0;
      rc = m24xx_page_size(eeprom_type,eeprom_addr,&page_size);
      if(rc != I2C_NO_ERR)
         break;
      if(page_size == 0)
      {
         rc = I2C_ERR_24XX_BAD_PAGESIZE;
         break;
      }
      rc = m24xx_set_addr(eeprom_type,eeprom_addr,eeprom_cs_val,
                                           &ctrl,&addr_hi,&addr_lo);
      if(rc != I2C_NO_ERR)
         break;

       //--- wr START + CONTROL
      rc = i2c_lpc_ctrl(ctrl & 0xFE); //-- Now WR (RD/WI = 0)
      if(rc != I2C_NO_ERR)
         break;
       //--- wr ADDRESS
      i2c_lpc_wr_byte(addr_hi);
      if(addr_lo != -1)
         i2c_lpc_wr_byte(addr_lo);

       //--- wr START + CONTROL again - for read start
      rc = i2c_lpc_ctrl(ctrl | 0x01); //-- Now RD (RD/WI = 1)
      if(rc != I2C_NO_ERR)
         break;

      rc = i2c_lpc_rx_to_buf(buf,num);
      if(rc != I2C_NO_ERR)
         break;

      i2c_lpc_stop();     //---- Set STOP ---

      break;
   }



   return rc;
}

