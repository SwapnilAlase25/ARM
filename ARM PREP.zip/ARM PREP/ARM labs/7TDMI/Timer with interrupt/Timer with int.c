#include<LPC214x.h>


void timer1_isr(void)__irq
{
	static int i=0;
	 T1IR|=(1<<0);
	//if(T1IR&(1<<0))
	//{
		if(i==0)
		{
		IO0CLR|=(1<<31);
		i=1;
		}
		else
		{
			IO0SET|=(1<<31);
			i=0;
		}
  //}
	T1TC=0x00;
	//T1TCR=0x01;
 	VICVectAddr=0x00;
}

void time_init()
{
	T1CTCR=0x00;
	T1PR=0x752F;
	VPBDIV=0x02;
	T1MR0=0x3E8;
	T1MCR|=(1<<0);
	IO0DIR|=(1<<31);
	IO0SET|=(1<<31);
	VICIntEnable=(1<<5);
	VICVectAddr1=(unsigned int)timer1_isr;
	VICVectCntl1=(0x20)|5;
	T1TCR=0x01;
}


int main()
{
time_init();
	
while(1)
	{
	
	}



}