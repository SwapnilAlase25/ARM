#include "LPC214x.h"

int main()
{

  IO0DIR|=(1<<31);                  //sets the direction of pin 31 of port 0 as output
	IO1DIR|=(1<<25);                  //sets the direction of pin 25 OF port 1 as output
 while(1) 
{	
  IO0SET|=(1<<31);	                //sets the bit value as 1, turns off the device
	IO1SET|=(1<<25);
	for(int i=0;i<=200000;i++);       //generates the delay 
  for(int i=0;i<=200000;i++);
	for(int i=0;i<=200000;i++);
	IO0CLR=(1<<31);                   //clears the bit value , turns on the devices
  IO1CLR|=(1<<25);
	for(int i=0;i<=200000;i++);
  for(int i=0;i<=200000;i++);       //generates the delay 
	for(int i=0;i<=200000;i++);
	

}
}
