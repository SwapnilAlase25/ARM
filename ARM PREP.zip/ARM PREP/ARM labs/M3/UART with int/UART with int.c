#include "lpc17xx.h"
#include "System_lpc17xx.h"
#include<string.h>
char Username[30];
char ch1;
int flag=0;
int j=0;
void UART3_IRQHandler(void)
{
  static int i=-1;
	
	if(LPC_UART3->IIR&(0x04))
	{
		  //while(i<30)
			//{
				ch1=LPC_UART3->RBR;
						i++;
				if(ch1=='\r')
				{
					Username[i]='\0';
					Username[i+i]='\n';
					flag=1;
				}
				else
				{
					Username[i]=ch1;
				}
			//}
			
}
}

void UART_init()
{
	LPC_GPIO2->FIODIRL|=(1<<9);
	LPC_GPIO2->FIOSETL|=(1<<9);
	LPC_PINCON->PINSEL0|=(1<<1)|(1<<3);
	LPC_SC->PCONP|=(1<<25);
	LPC_SC->PCLKSEL1=0x00;
	LPC_UART3->IER|=(1<<0);
	LPC_UART3->LCR|=(1<<1)|(1<<0);
	LPC_UART3->LCR|=(1<<7);
	LPC_UART3->DLL=0x000A2;
	LPC_UART3->DLM=0x00;
	LPC_UART3->FDR|=(1<<4);
	LPC_UART3->LCR&=(~(1<<7));
  LPC_UART3->TER=(1<<7);
	NVIC_EnableIRQ(UART3_IRQn);
	
}

int main()
{
	SystemInit();
	UART_init();
	char ch[30]={'W','E','L','C','O','M','E'};
	for(int i=0;ch[i]!='\0';i++)
	{
	LPC_UART3->THR=ch[i];
	while(!(LPC_UART3->LSR&(1<<5)));	
	}

	while(1)
		{
					if(flag==1)
					{
						while(j<=(strlen(Username)))
						{
							while(!(LPC_UART3->LSR&(1<<5)));
		          LPC_UART3->THR=Username[j];
							j++;
						}
						flag=0;
					}
			//while(!(LPC_UART3->LSR&(1<<5)));
	  }
	
}
