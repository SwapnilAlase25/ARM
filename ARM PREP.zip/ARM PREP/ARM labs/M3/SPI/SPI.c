#include<lpc17xx.h>
#include "System_lpc17xx.h"

void EINT2_IRQHandler(void)
{
for(int j=0;j<100000;j++);
	char ch;
	static int i=0;
	LPC_SC->EXTINT|=(1<<2);
		if(i==0)
		{
	LPC_GPIO0->FIOSET|=(1<<16);
	LPC_SPI->SPDR=0xA0;
	while(!(LPC_SPI->SPSR&(1<<7)));
	
	LPC_GPIO0->FIOCLR|=(1<<16);
		ch=LPC_SPI->SPSR;
	ch=LPC_SPI->SPDR;
			i=1;
  }
	if(i==1)
	{
		LPC_GPIO0->FIOSET|=(1<<16);
	LPC_SPI->SPDR=0x0A;
	while(!(LPC_SPI->SPSR&(1<<7)));
	LPC_GPIO0->FIOCLR|=(1<<16);
	ch=LPC_SPI->SPSR;
	ch=LPC_SPI->SPDR;
		i=0;
	}
	
}
void SPI_init()
{
	LPC_PINCON->PINSEL0|=(1<<31)|(1<<30);
	LPC_PINCON->PINSEL1|=(1<<4)|(1<<5);
	LPC_GPIO0->FIODIR|=(1<<16);
	LPC_SC->PCLKSEL0|=0x00;
	LPC_SPI->SPCCR=0xFE;
	LPC_SPI->SPCR=0x00;
	LPC_SPI->SPCR=(1<<5)|(1<<6)|(1<<11);
}

void Ext_int()
{
	LPC_PINCON->PINSEL4|=(1<<24);
  LPC_SC->EXTINT=(1<<2);
	LPC_SC->EXTMODE=(~(1<<2));
	LPC_SC->EXTPOLAR=(~(1<<2));
	NVIC_EnableIRQ(EINT2_IRQn);
}

int main()
{
	SystemInit();
	SPI_init();
  Ext_int();
  while(1);	
	
}
