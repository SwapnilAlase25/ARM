#include<LPC17xx.h>
#include<system_LPC17xx.h>
void UART_init()
{
	LPC_SC->PCONP=(1<<25);
	LPC_SC->PCLKSEL1=0x00; //set clk on 25 MHz
  LPC_PINCON->PINSEL0|=(1<<1)|(1<<3);	//select UART3
	LPC_UART3->LCR|=(1<<0)|(1<<1);
	LPC_UART3->LCR=(1<<7);
	LPC_UART3->DLL=0x98; //dll 152in dec
	LPC_UART3->DLM=0x00;
	LPC_UART3->FDR=(1<<4);
	LPC_UART3->LCR&=(~(1<<7));
	LPC_UART3->TER=(1<<7);
	
	
}


int main()
{
	char x;
SystemInit();
	UART_init();
	while(1)
	{
	while(!(LPC_UART3->LSR&(1<<0)));
		x=LPC_UART3->RBR;
	while(!(LPC_UART3->LSR&(1<<5)));
		LPC_UART3->THR=x;
	}

	}