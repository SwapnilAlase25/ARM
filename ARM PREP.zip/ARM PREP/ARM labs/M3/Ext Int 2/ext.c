#include <LPC17xx.h>
#include "lcd.h"	

void delay1(void)
{
	int i,j;

	for(i=0;i<=0xFFF;i++)
	for(j=0;j<=0xFFF;j++);
}	

void EINT2_IRQHandler(void)
{
	delay1();
	static int i=0;
	LPC_SC->EXTINT|=(1<<2);
	if(i==0)
	{
		LPC_GPIO2->FIOSET1=(1<<1);              //setting LED to turn off
		send_cmd(0x80);
	  user_string("CDAC");
		delay1();
		i=1;
	}
	else
	{
		LPC_GPIO2->FIOCLR1=(1<<1);             //clearing LED to turn off
		send_cmd(0xc0);
	 user_string("ACTS");
		delay1();
		i=0;
	}
	
}

void Ext_Int_Init()
{
	SystemInit();
	LPC_GPIO2->FIODIR1=(1<<1);
	LPC_PINCON->PINSEL4=(1<<24);
	LPC_SC->EXTMODE&=(~(1<<2));
	LPC_SC->EXTPOLAR&=(~(0<<2));
	NVIC_EnableIRQ(EINT2_IRQn);
	init_lcd();
}

int main()
{
	Ext_Int_Init();
while(1)
{
	
}

}
