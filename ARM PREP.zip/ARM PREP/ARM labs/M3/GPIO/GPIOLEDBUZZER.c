/* GPIO : LED and Buzzer 
   Processor:Cortex M3
   Micro controller : LPC1768
   Author:PRN_087_091
   Aim:To make the LED and Buzzer turn on and off.
*/	 

#include "LPC17xx.h"                                    // Device header
void delay(uint16_t n);                                 // Delay function declaration
int main()                                              //main function
{                                                       
LPC_PINCON->PINSEL4&=~((1<<22)|(1<<23)|(1<<18)|(1<<19));//Sets PORT 2 pins 9 and 11 as GPIO 
LPC_GPIO2->FIODIR1|=	(1<<3)|(1<<1);                    //Sets the PORT2 pins 9 and 11 as output pins
while(1)                                                //enables continuos execution of code
{                                                       
  LPC_GPIO2->FIOSET1|=(1<<1)|(1<<3);                    //Sets the Pin 9 and 11 of Port2 to turn off the LED and Buzzer
	delay(1000);                                           //Calls the delay function to hold the result
	LPC_GPIO2->FIOCLR1|=(1<<1)|(1<<3);                    //Clears the Pin 9 and 11 of Port2 to turn the LED and Buzzer on, active low
	delay(1000);                                           //Calls the delay function to hold the result
}	
}
void delay(uint16_t n)                                  //Delay function definition
{
for(uint16_t i=0;i<=n;i++)                              //The inner and out loop together generate the delay 
	{
	for(uint16_t j=0; j<=6000;j++);                      //counts till 60000 to generate a random delay
}
}
