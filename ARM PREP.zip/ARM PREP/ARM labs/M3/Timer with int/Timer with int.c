#include<LPC17xx.h>
#include "system_LPC17xx.h"

void TIMER0_IRQHandler()
{
		static int i=0;
		LPC_TIM0->IR|=0x01;

	if(i==0)
	{
		LPC_GPIO2->FIOSET1|=(1<<1)|(1<<3); 
		i=1;
	}
	else
		{
		LPC_GPIO2->FIOCLR1|=(1<<1)|(1<<3);     
    i=0;			
		}
	LPC_TIM0->TC=0x00;
}


void timer_init()
{
	
  LPC_PINCON->PINSEL4&=~((1<<22)|(1<<23)|(1<<18)|(1<<19));//Sets PORT 2 pins 9 and 11 as GPIO 
	LPC_GPIO2->FIODIR1|=	(1<<3)|(1<<1);  
	LPC_GPIO2->FIOCLR1|=(1<<1)|(1<<3);
	LPC_SC->PCONP|= (1<<1);
	LPC_SC->PCLKSEL0=(1<<3);
	LPC_TIM0->CTCR|=0x00;
	LPC_TIM0->PR=0xC34F;
	LPC_TIM0->MR0=0x3EB;
	LPC_TIM0->TCR|=0x02;
  LPC_TIM0->MCR|=(1<<0);
	//LPC_TIM0->MCR|=(1<<1);
	LPC_TIM0->TCR=0x01;
	NVIC_EnableIRQ(TIMER0_IRQn);
}

int main()
{
	SystemInit();
	timer_init();
	
	while(1)
	{
	}
}
