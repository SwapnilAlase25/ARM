#include<lpc17xx.h>
#include "System_LPC17xx.h"
#include "LCD.h"
#include <string.h>

void ADC_IRQHandler(void)
{
	if(LPC_ADC->ADSTAT&0x04)
	{
	char p[10];
	long data;
	float data1;
	data=((LPC_ADC->ADDR2>>4)&0xFFF);
	data1=data*((3.3)/4096);
  sprintf(p,"Voltage=%.3f",data1);
	send_cmd(0x01);	
	delay();
	send_cmd(0x80);
	delay();
	for(int i=0;p[i]!='\0';i++)
	{
	send_data(p[i]);
	}
	delay();
 }
}
void ADC_int()
{
	LPC_PINCON->PINSEL1|=(1<<18);
	LPC_SC->PCONP|=(1<<12);
	LPC_SC->PCLKSEL0|=0x00;
	LPC_ADC->ADCR|=(1<<2)|(1<<9)|(1<<16)|(1<<21);
  LPC_ADC->ADINTEN|=(1<<2);
	NVIC_EnableIRQ(ADC_IRQn);
}	

int main()
{
	SystemInit();
	init_lcd();
	ADC_int();
	while(1)
	{
 	/*char p[10];
	long data;
	float data1;
	data=((LPC_ADC->ADDR2>>4)&0xFFF);
	data1=data*(3.3/4096);
  sprintf(p,"%f",data1);
	send_cmd(0x01);
	delay();
	send_cmd(0x80);
	delay();
	for(int i=0;i<10;i++)
	{
	send_data(p[i]);
		delay();
	}
		*/
	}
		
}